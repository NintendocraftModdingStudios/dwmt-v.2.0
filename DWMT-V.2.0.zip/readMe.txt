Hello !!! 
To run this, please i nstall node as well as:
	npm init -y
	npm install "plugin"
	1. express
	2. path
	3. cors
	4. fs

Nice , that you found you way here!

Use this to get an Image of what you can do with the easiest programminglanguages HTML,CSS and JS.

Credits: 
 JavaScript Code: mostly ChatGPT (Chat.openai.com)
 Warning-Icons: Deutscher Wetterdienst and licensed under (C) 2024 DWD (dwd.de) 
 --> Icons from DWD are used with other warn-classes and they were edited by me!

Style: Nintendocraft Modding Studios
HTML: Nintedocraft Modding Studios

All Rights Reserved! 

Copyright (C) 2024 Nintendocraft Modding Studios

Do not upload this Project on any other platform whithout my written Permition! 

This Site will eventually get many Upgrades in the future, so stay tuned!