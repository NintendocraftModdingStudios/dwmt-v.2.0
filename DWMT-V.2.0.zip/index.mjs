import express from 'express';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';
import cors from 'cors';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cors());

app.use(express.static(path.join(__dirname, 'seiten')));
app.use('/pictures', express.static(path.join(__dirname, 'seiten', 'pictures')));
app.use('/css', express.static(path.join(__dirname, 'seiten', 'css')));

// Routen für verschiedene Seiten
app.get('/', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'seiten', 'index.html'));
});

// Weitere Routen hier einfügen, wie bereits vorhanden

// Benutzerdaten (Beispiel)
const users = {
    'user1': { password: 'admin', isAdmin: true },
    'user2': { password: '123', isAdmin: false },
    'user3': { password: 'abc', isAdmin: false },
    'user4': { password: '&&&', isAdmin: false}
};

// Login-Route
app.post('/login', (req, res) => {
    const { username, password, admin } = req.body;

    if (users[username] && users[username].password === password) {
        if (admin === 'on' && users[username].isAdmin) {
            return res.sendFile(path.resolve(__dirname, 'seiten', 'admin.index.html'));
        } else {
            return res.sendFile(path.resolve(__dirname, 'seiten', 'sec.index.html'));
        }
    } else {
        return res.sendFile(path.resolve(__dirname, 'seiten', 'fail.html'));
    }
});

app.get('/login', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'seiten', 'login.html'));
});

// Pfad zur JSON-Datei für Warnungen
const warnungenFilePath = path.join(__dirname, 'seiten', 'warnungen.json');

// GET /warnungen
app.get('/warnungen', (req, res) => {
    fs.readFile(warnungenFilePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Fehler beim Lesen der Warnungen:', err);
            res.status(500).json({ error: 'Fehler beim Lesen der Warnungen' });
            return;
        }
        res.json(JSON.parse(data));
    });
});

// POST /warnungen
app.post('/warnungen', (req, res) => {
    fs.readFile(warnungenFilePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Fehler beim Lesen der Warnungen:', err);
            res.status(500).json({ error: 'Fehler beim Lesen der Warnungen' });
            return;
        }
        const warnungen = JSON.parse(data);
        const newWarnung = req.body;
        warnungen.push(newWarnung);

        fs.writeFile(warnungenFilePath, JSON.stringify(warnungen, null, 2), (err) => {
            if (err) {
                console.error('Fehler beim Speichern der Warnungen:', err);
                res.status(500).json({ error: 'Fehler beim Speichern der Warnungen' });
                return;
            }
            res.status(201).json(newWarnung);
        });
    });
});

// DELETE /warnungen/:index
app.delete('/warnungen/:index', (req, res) => {
    fs.readFile(warnungenFilePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Fehler beim Lesen der Warnungen:', err);
            res.status(500).json({ error: 'Fehler beim Lesen der Warnungen' });
            return;
        }
        const warnungen = JSON.parse(data);
        const index = parseInt(req.params.index, 10);

        if (index >= 0 && index < warnungen.length) {
            warnungen.splice(index, 1);

            fs.writeFile(warnungenFilePath, JSON.stringify(warnungen, null, 2), (err) => {
                if (err) {
                    console.error('Fehler beim Speichern der Warnungen nach dem Löschen:', err);
                    res.status(500).json({ error: 'Fehler beim Speichern der Warnungen nach dem Löschen' });
                    return;
                }
                res.status(204).end();
            });
        } else {
            res.status(404).json({ error: 'Warnung nicht gefunden' });
        }
    });
});

// Pfad zur JSON-Datei
const filePath = path.join(__dirname, 'seiten/hochwasserbericht.json');

// POST-Endpunkt zum Speichern der Berichte
app.post('/hochwasserbericht', (req, res) => {
    const { title, icon, desc, warnzeitraum } = req.body;

    // Validieren der eingehenden Daten
    if (!title || !icon || !desc || !warnzeitraum) {
        return res.status(400).send('Bad Request: Fehlende erforderliche Felder');
    }

    console.log('Daten empfangen:', req.body); // Debugging-Ausgabe

    // Lesen der vorhandenen Daten aus der JSON-Datei
    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Fehler beim Lesen der Datei:', err); // Debugging-Ausgabe
            return res.status(500).send('Server Error: Datei konnte nicht gelesen werden');
        }

        const berichte = data ? JSON.parse(data) : [];
        berichte.push({ title, icon, desc, warnzeitraum });

        // Schreiben der aktualisierten Daten in die JSON-Datei
        fs.writeFile(filePath, JSON.stringify(berichte, null, 2), (err) => {
            if (err) {
                console.error('Fehler beim Schreiben der Datei:', err); // Debugging-Ausgabe
                return res.status(500).send('Server Error: Datei konnte nicht geschrieben werden');
            }

            res.status(201).send({ message: 'Bericht erfolgreich erstellt' });
        });
    });
});

// GET-Endpunkt zum Abrufen der Berichte
app.get('/hochwasserbericht', (req, res) => {
    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Fehler beim Lesen der Datei:', err); // Debugging-Ausgabe
            return res.status(500).send('Server Error: Datei konnte nicht gelesen werden');
        }

        const berichte = data ? JSON.parse(data) : [];
        res.status(200).json(berichte);
    });
});

// DELETE /hochwasserbericht/:index
app.delete('/hochwasserbericht/:index', (req, res) => {
    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Fehler beim Lesen der Datei:', err); // Debugging-Ausgabe
            return res.status(500).send('Server Error: Datei konnte nicht gelesen werden');
        }
        const berichte = JSON.parse(data);
        const index = parseInt(req.params.index, 10);

        if (index >= 0 && index < berichte.length) {
            berichte.splice(index, 1);

            fs.writeFile(filePath, JSON.stringify(berichte, null, 2), (err) => {
                if (err) {
                    console.error('Fehler beim Schreiben der Datei:', err); // Debugging-Ausgabe
                    return res.status(500).send('Server Error: Datei konnte nicht geschrieben werden');
                }
                res.status(204).send();
            });
        } else {
            res.status(404).json({ error: 'Bericht nicht gefunden' });
        }
    });
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
