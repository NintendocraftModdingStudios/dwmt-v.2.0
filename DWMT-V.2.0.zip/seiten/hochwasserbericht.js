document.addEventListener('DOMContentLoaded', () => {
    loadIcon();
    loadBerichte();
});

function toggleForm() {
    const formContainer = document.getElementById('flut-form');
    formContainer.classList.toggle('active');
}

function loadIcon() {
    const iconSelect = document.getElementById('flut-warnung-icon');
    const icons = [
        "hochwasser_ms1.png",
        "hochwasser_ms2.png",
        "hochwasser_ms3.png",
        "hochwasser_ms4.png",
        "hochwasser_ms5.png"
    ];
    
    icons.forEach(icon => {
        const option = document.createElement('option');
        option.value = icon;
        option.textContent = icon;
        iconSelect.appendChild(option);
    });
}

function saveBerichte(event) {
    event.preventDefault();
    const warnzeitraum = document.getElementById('flut-warnzeitraum').value;
    const title = document.getElementById('flut-warnung-title').value;
    const icon = document.getElementById('flut-warnung-icon').value;
    const desc = document.getElementById('flut-warnung-desc').value;

    if (title && icon && desc && warnzeitraum) {
        const berichtData = { title, icon, desc, warnzeitraum };
        console.log('Zu sendende Berichtsdaten:', berichtData); // Protokollieren der Daten

        fetch('/hochwasserbericht', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(berichtData)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP-Fehler! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            loadBerichte();
            toggleForm();
        })
        .catch(error => {
            console.error('Fehler:', error);
        });
    } else {
        alert('Bitte alle Felder ausfüllen');
    }
}

document.getElementById('flut-form').addEventListener('submit', saveBerichte);



function loadBerichte() {
    fetch('/hochwasserbericht')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP-Fehler! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(berichte => {
            const flutwarnungenContainer = document.getElementById('flut-container-admin');
            flutwarnungenContainer.innerHTML = '';

            berichte.forEach((bericht, index) => {
                const berichtDiv = document.createElement('div');
                berichtDiv.className = 'warnung';

                const titleDiv = document.createElement('div');
                titleDiv.className = 'warnung-title';
                titleDiv.textContent = bericht.title;

                const iconImg = document.createElement('img');
                iconImg.src = `icons/${bericht.icon}`;
                iconImg.className = 'warnung-icon';

                const descDiv = document.createElement('div');
                descDiv.className = 'warnung-text';
                descDiv.textContent = bericht.desc;

                const warnzeitraumDiv = document.createElement('div');
                warnzeitraumDiv.className = 'warnzeitraum';
                warnzeitraumDiv.textContent = `Warnzeitraum: ${bericht.warnzeitraum}`;

                const deleteButton = document.createElement('button');
                deleteButton.textContent = 'Löschen';
                deleteButton.onclick = () => {
                    deleteBericht(index);
                };

                berichtDiv.appendChild(titleDiv);
                berichtDiv.appendChild(iconImg);
                berichtDiv.appendChild(warnzeitraumDiv);
                berichtDiv.appendChild(descDiv);
                berichtDiv.appendChild(deleteButton);

                flutwarnungenContainer.appendChild(berichtDiv);
            });
        })
        .catch(error => {
            console.error('Fehler:', error);
        });
}

function deleteBericht(index) {
    fetch(`/hochwasserbericht/${index}`, {
        method: 'DELETE'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP-Fehler! Status: ${response.status}`);
        }
        loadBerichte();
    })
    .catch(error => {
        console.error('Fehler:', error);
    });
}
