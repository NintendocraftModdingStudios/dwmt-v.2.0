document.addEventListener('DOMContentLoaded', () => {
    loadBerichte();
});

function loadBerichte() {
    fetch('/hochwasserbericht')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP-Fehler! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(berichte => {
            const flutwarnungenContainer = document.getElementById('flut-container');
            flutwarnungenContainer.innerHTML = '';

            berichte.forEach((bericht, index) => {
                const berichtDiv = document.createElement('div');
                berichtDiv.className = 'warnung';

                const titleDiv = document.createElement('div');
                titleDiv.className = 'warnung-title';
                titleDiv.textContent = bericht.title;

                const iconImg = document.createElement('img');
                iconImg.src = `icons/${bericht.icon}`;
                iconImg.className = 'warnung-icon';

                const descDiv = document.createElement('div');
                descDiv.className = 'warnung-text';
                descDiv.textContent = bericht.desc;

                const warnzeitraumDiv = document.createElement('div');
                warnzeitraumDiv.className = 'warnzeitraum';
                warnzeitraumDiv.textContent = `Warnzeitraum: ${bericht.warnzeitraum}`;

                

                berichtDiv.appendChild(titleDiv);
                berichtDiv.appendChild(iconImg);
                berichtDiv.appendChild(warnzeitraumDiv);
                berichtDiv.appendChild(descDiv);
                

                flutwarnungenContainer.appendChild(berichtDiv);
            });
        })
        .catch(error => {
            console.error('Fehler:', error);
        });
}