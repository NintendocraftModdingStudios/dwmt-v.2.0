document.addEventListener('DOMContentLoaded', () => {
    loadIcons();
    loadWarnungen();
});

function toggleForm() {
    const formContainer = document.getElementById('form-container');
    formContainer.classList.toggle('active');
}

function loadIcons() {
    const iconSelect = document.getElementById('warnung-icon');
    const icons = [
        'twd_ico_gewitterwarnung.1.png',
        'twd_ico_gewitterwarnung.2.png',
        'twd_ico_gewitterwarnung.3.png',
        'twd_ico_gewitterwarnung.4.png',
        'twd_ico_gewitterwarnung.5.png',
        'twd_ico_gewitterwarnung.6.AGW.png',
        'twd_ico_gewitterwarnung.7.EAGW.png'
    ];
    
    icons.forEach(icon => {
        const option = document.createElement('option');
        option.value = icon;
        option.textContent = icon;
        iconSelect.appendChild(option);
    });
}

function saveWarnung(event) {
    event.preventDefault();
    const warnzeitraum = document.getElementById('warnzeitraum').value;
    const title = document.getElementById('warnung-title').value;
    const icon = document.getElementById('warnung-icon').value;
    const desc = document.getElementById('warnung-desc').value;

    if (title && icon && desc && warnzeitraum) {
        fetch('/warnungen', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ title, icon, desc, warnzeitraum })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP-Fehler! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            loadWarnungen();
            toggleForm();
        })
        .catch(error => {
            console.error('Fehler:', error);
        });
    } else {
        alert('Bitte alle Felder ausfüllen');
    }
}

document.getElementById('warnung-form').addEventListener('submit', saveWarnung);

function loadWarnungen() {
    fetch('/warnungen')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP-Fehler! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(warnungen => {
            const warnungenContainer = document.getElementById('warnungen-container-admin');
            warnungenContainer.innerHTML = '';

            warnungen.forEach((warnung, index) => {
                const warnungDiv = document.createElement('div');
                warnungDiv.className = 'warnung';

                const titleDiv = document.createElement('div');
                titleDiv.className = 'warnung-title';
                titleDiv.textContent = warnung.title;

                const iconImg = document.createElement('img');
                iconImg.src = `icons/${warnung.icon}`;
                iconImg.className = 'warnung-icon';

                const descDiv = document.createElement('div');
                descDiv.className = 'warnung-text';
                descDiv.textContent = warnung.desc;

                const warnzeitraumDiv = document.createElement('div');
                warnzeitraumDiv.className = 'warnzeitraum';
                warnzeitraumDiv.textContent = `Warnzeitraum: ${warnung.warnzeitraum}`;

                const deleteButton = document.createElement('button');
                deleteButton.textContent = 'Löschen';
                deleteButton.onclick = () => {
                    deleteWarnung(index);
                };

                warnungDiv.appendChild(titleDiv);
                warnungDiv.appendChild(iconImg);
                warnungDiv.appendChild(warnzeitraumDiv);
                warnungDiv.appendChild(descDiv);
                warnungDiv.appendChild(deleteButton);

                warnungenContainer.appendChild(warnungDiv);
            });
        })
        .catch(error => {
            console.error('Fehler:', error);
        });
}

function deleteWarnung(index) {
    fetch(`/warnungen/${index}`, {
        method: 'DELETE'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP-Fehler! Status: ${response.status}`);
        }
        loadWarnungen();
    })
    .catch(error => {
        console.error('Fehler:', error);
    });
}
